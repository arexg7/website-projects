<?php
session_start();
require __DIR__ . '/db.php';

$error = "";

// Register Form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Validation
    if (empty($username) || empty($email) || empty($password) || empty($password_confirm)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif ($password !== $password_confirm) {
        $error = "Passwords do not match.";
    } else {
        // Check if user exists already
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            $error = "Username or email already taken.";
        } else {
            // Insert user with hashed password
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"
            );
            if ($stmt->execute([$username, $email, $password_hash])) {
                header("Location: login.php?success=1");
                exit;
            } else {
                $error = "Registration failed. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - Gaming Store</title>

<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/register.css">
</head>

<body>
<header>
  <a href="../Home.php" style="text-decoration:none;color:inherit">
    <h1>That Gaming Merch Store</h1>
  </a>
  <h2>Register</h2>
</header>

<div class="auth-container">

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" action="" novalidate>

  <label for="username">Username</label>
  <input
      id="username"
      name="username"
      type="text"
      required
      maxlength="50"
      pattern="[A-Za-z0-9_\-]{3,50}"
      title="3–50 chars: letters, numbers, _ or -">

  <label for="email">Email</label>
  <input
      id="email"
      name="email"
      type="email"
      required
      maxlength="255">

  <label for="password">Password</label>
  <input
      id="password"
      name="password"
      type="password"
      required
      minlength="8">

  <label for="password_confirm">Confirm Password</label>
  <input
      id="password_confirm"
      name="password_confirm"
      type="password"
      required
      minlength="8">

  <button class="ctc submit-btn" type="submit">Register</button>

</form>

<p style="margin-top:1rem;">
  Already have an account?
  <a href="login.php?login=1">Login here</a>
</p>

</div>

<!-- ✅ SAFE JavaScript Validation -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (e) {
        const username = document.getElementById("username").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const confirm = document.getElementById("password_confirm").value;

        const usernameRegex = /^[A-Za-z0-9_-]{3,50}$/;

        if (!usernameRegex.test(username)) {
            alert("Username must be 3–50 characters and contain only letters, numbers, _ or -");
            e.preventDefault();
            return;
        }

        if (!email.includes("@")) {
            alert("Please enter a valid email address.");
            e.preventDefault();
            return;
        }

        if (password.length < 8) {
            alert("Password must be at least 8 characters long.");
            e.preventDefault();
            return;
        }

        if (password !== confirm) {
            alert("Passwords do not match.");
            e.preventDefault();
            return;
        }
    });
});
</script>

</body>
</html>
