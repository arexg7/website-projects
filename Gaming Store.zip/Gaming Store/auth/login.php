<?php
session_start();
require __DIR__ . '/db.php';

$error = "";

/*
 Redirects IF:
 - User is already logged in
 - They are opening the page normally
*/
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_SESSION['user_id'])) {
    header("Location: ../Home.php");
    exit;
}

/* Form submission handling */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_email = trim($_POST['username_email']);
    $password = $_POST['password'];

    if (empty($username_email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $stmt = $pdo->prepare(
            "SELECT id, username, password_hash 
             FROM users 
             WHERE username = ? OR email = ?"
        );
        $stmt->execute([$username_email, $username_email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: ../Home.php");
            exit;
        } else {
            $error = "Invalid username/email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Gaming Store</title>
<link rel="stylesheet" href="../css/styles.css">
<link rel="stylesheet" href="../css/login.css">
</head>
<body>
<header>
  <a href="../Home.php" style="text-decoration:none;color:inherit"><h1>That Gaming Merch Store</h1></a>
  <h2>Login</h2>
</header>

<div class="auth-container">
<?php if (!empty($error)) echo '<div class="error">' . htmlspecialchars($error) . '</div>'; ?>
<?php if (!empty($_GET['success'])) echo '<div class="success">Registration successful. You can log in now.</div>'; ?>

<form method="post" action="">
  <label for="username_email">Username or Email</label>
  <input id="username_email" name="username_email" type="text" required>

  <label for="password">Password</label>
  <input id="password" name="password" type="password" required>

  <button class="ctc submit-btn" type="submit">Login</button>
</form>

<p style="margin-top:1rem;">Don't have an account? <a href="register.php">Register here</a></p>
</div>
</body>
</html>
