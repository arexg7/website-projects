<?php
session_start();
require __DIR__ . '/db.php'; // make sure db.php connects to store_users_db

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    header("Location: login.php?login_required=1");
    exit;
}

// Get POST data safely
$product_id = $_POST['product_id'] ?? '';
$product_name = $_POST['product_name'] ?? '';
$price = $_POST['price'] ?? 0;

// Basic validation
if (!$product_id || !$product_name || !$price) {
    die("Invalid product data.");
}

// Check if this product is already in the cart for this user
$stmt = $pdo->prepare("SELECT id, quantity FROM carts WHERE user_id = ? AND product_id = ?");
$stmt->execute([$_SESSION['user_id'], $product_id]);
$cart_item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($cart_item) {
    // If already in cart, increase quantity
    $stmt = $pdo->prepare("UPDATE carts SET quantity = quantity + 1 WHERE id = ?");
    $stmt->execute([$cart_item['id']]);
} else {
    // If not in cart, insert new row
    $stmt = $pdo->prepare("INSERT INTO carts (user_id, product_name, product_id, price) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $product_name, $product_id, $price]);
}

// Redirect back to the page the user came from
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
?>
