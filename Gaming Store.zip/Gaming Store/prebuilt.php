<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>That Gaming Merch Store</title>
    <link rel="stylesheet" href="css/prebuilt.css">
</head>

<body>

<header class="main-header">
    <div class="header-content">
        <div class="header-text">
            <h1>
                <a href="Home.php" class="title-link">That Gaming Merch Store</a>
            </h1>
            <h2>Gear Up, Game on!</h2>
        </div>

            <div class="auth-links">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span> |
        <a href="cart.php" class="cart-link">
            🛒 Cart
            <?php
            // Optional: Show number of items in cart
            require 'auth/db.php';
            $stmt = $pdo->prepare("SELECT SUM(quantity) AS total_items FROM carts WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $cart_count = $stmt->fetch(PDO::FETCH_ASSOC)['total_items'];
            if ($cart_count > 0) {
                echo " ($cart_count)";
            }
            ?>
                </a> |
                <a href="auth/logout.php">Logout</a>
        <?php else: ?>
                  <a href="auth/login.php">Login</a> |
                  <a href="auth/register.php">Register</a>
                 <?php endif; ?>
            </div>
    </div>
</header>

<div class="prebuilt-list">

    <div class="prebuilt-card">
        <img src="images/prebuilt/IMG-20240226-WA0015.jpg" alt="Gaming PC RTX 3060">
        <div class="prebuilt-info">
            <h3>Gaming PC RTX 3060</h3>
            <p class="specs">Ryzen 5 • 16GB RAM • 1TB SSD</p>
            <p class="price">Rs 45,000</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="PC1">
                <input type="hidden" name="product_name" value="RTX3060">
                <input type="hidden" name="price" value="1200">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="prebuilt-card">
        <img src="images/prebuilt/IMG-20240226-WA0016.jpg" alt="Gaming PC RTX 4060">
        <div class="prebuilt-info">
            <h3>Gaming PC RTX 4060</h3>
            <p class="specs">Intel i7 • 32GB RAM • 2TB SSD</p>
            <p class="price">Rs 62,000</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="PC2">
                <input type="hidden" name="product_name" value="RTX4060">
                <input type="hidden" name="price" value="1200">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

</div>

</body>
</html>
