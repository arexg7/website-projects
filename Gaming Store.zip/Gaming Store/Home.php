<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>That Gaming Merch Store</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="home-page">

<header class="main-header">
    <div class="header-content">
        <div class="header-text">
            <h1>
                <a href="Home.php" class="title-link">That Gaming Merch Store</a>
            </h1>
            <h2>Gear Up, Game on!</h2>
        </div>

            <div class="auth-links">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span> |
        <a href="cart.php" class="cart-link">
            🛒 Cart
            <?php
            // Optional: Show number of items in cart
            require 'auth/db.php';
            $stmt = $pdo->prepare("SELECT SUM(quantity) AS total_items FROM carts WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $cart_count = $stmt->fetch(PDO::FETCH_ASSOC)['total_items'];
            if ($cart_count > 0) {
                echo " ($cart_count)";
            }
            ?>
                </a> |
                <a href="auth/logout.php">Logout</a>
        <?php else: ?>
                  <a href="auth/login.php">Login</a> |
                  <a href="auth/register.php">Register</a>
                 <?php endif; ?>
            </div>
    </div>
</header>

<div class="container">
    <section id="productList">
        <div class="product">
            <h2>Anime Merch</h2>
            <img src="images/anime.jpg" alt="Anime Merch">
            <p>For all our weebs out there, we have what you want.</p>
            <a href="anime_merch.php" class="ctc">Click to browse</a>
        </div>

        <div class="product">
            <h2>Computer Accessories</h2>
            <img src="images/cpacc.jpg" alt="Computer Accessories">
            <p>Check out accessories that will elevate your gameplay.</p>
            <a href="computer_accesories.php" class="ctc">Click to browse</a>
        </div>

        <div class="product">
            <h2>Computer Parts</h2>
            <img src="images/cpparts.jpg" alt="Computer Parts">
            <p>Want to build your own PC? You're at the right place.</p>
            <a href="computer_parts.php" class="ctc">Click to browse</a>
        </div>

        <div class="product">
            <h2>Gaming Consoles</h2>
            <img src="images/console.jpg" alt="Gaming Consoles">
            <p>Explore our catalog of gaming consoles.</p>
            <a href="gaming_consoles.php" class="ctc">Click to browse</a>
        </div>

        <div class="product">
            <h2>Pre-Built Computers</h2>
            <img src="images/prebuilt.jpg" alt="Prebuilt PCs">
            <p>Check out our pre-built computers ready for deployment.</p>
            <a href="prebuilt.php" class="ctc">Click to browse</a>
        </div>

        <div class="product">
            <h2>Video Games and Services</h2>
            <img src="images/services.jpg" alt="Games and Services">
            <p>You can't play video games without games so check out our collection.</p>
            <a href="videogames_services.php" class="ctc">Click to browse</a>
        </div>
    </section>

    <section class="contact-section">
        <h2>Contact Us</h2>
        <p>Email: info@thatgamingmerchstore.com</p>
        <p>Phone: 57654321</p>
        <p>Address: Royal Road Curepipe, Mauritius</p>
    </section>
</div>

</body>
</html>
