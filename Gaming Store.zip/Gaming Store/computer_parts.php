<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>That Gaming Merch Store</title>
    <link rel="stylesheet" href="css/computerparts.css">
</head>

<body>

    <header class="main-header">
    <div class="header-content">
        <div class="header-text">
            <h1>
                <a href="Home.php" class="title-link">That Gaming Merch Store</a>
            </h1>
            <h2>Gear Up, Game on!</h2>
        </div>

            <div class="auth-links">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span> |
        <a href="cart.php" class="cart-link">
            🛒 Cart
            <?php
            // Optional: Show number of items in cart
            require 'auth/db.php';
            $stmt = $pdo->prepare("SELECT SUM(quantity) AS total_items FROM carts WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $cart_count = $stmt->fetch(PDO::FETCH_ASSOC)['total_items'];
            if ($cart_count > 0) {
                echo " ($cart_count)";
            }
            ?>
                </a> |
                <a href="auth/logout.php">Logout</a>
        <?php else: ?>
                  <a href="auth/login.php">Login</a> |
                  <a href="auth/register.php">Register</a>
                 <?php endif; ?>
            </div>
    </div>
</header>
    <main class="coming-soon-container">
        <h1 class="coming-soon-text">Coming Soon...</h1>
    </main>

</body>