<?php
session_start();
require 'auth/db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// --- Remove item directly if remove_id is set ---
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    $stmt = $pdo->prepare("DELETE FROM carts WHERE id = ? AND user_id = ?");
    $stmt->execute([$remove_id, $user_id]);
    
    // Redirect to avoid resubmission
    header("Location: cart.php");
    exit;
}

// Fetch user's cart items
$stmt = $pdo->prepare("SELECT * FROM carts WHERE user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total
$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Cart - That Gaming Merch Store</title>
<link rel="stylesheet" href="css/cart.css">
</head>
<body>

<header>
    <h1><a href="Home.php" class="title-link">That Gaming Merch Store</a></h1>
    <h2>Your Shopping Cart</h2>
</header>

<main class="cart-container">
    <?php if (empty($cart_items)) : ?>
        <p class="empty-cart">Your cart is empty.</p>
        <a href="Home.php" class="ctc">Continue Shopping</a>
    <?php else: ?>
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cart_items as $item) : ?>
                    <tr>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td>Rs <?= number_format($item['price'], 2) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>Rs <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        <td>
                            <!-- Remove item link directly handled in this page -->
                            <a href="cart.php?remove_id=<?= $item['id'] ?>" class="remove-btn">Remove</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="cart-total">
            <strong>Total: Rs <?= number_format($total, 2) ?></strong>
        </div>

        <div class="cart-actions">
            <a href="Home.php" class="ctc">Continue Shopping</a>
            <a class="checkout-btn">Proceed to Checkout</a>
        </div>
    <?php endif; ?>
</main>

</body>
</html>
