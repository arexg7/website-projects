<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Games - That Gaming Merch Store</title>
    <link rel="stylesheet" href="css/vgservices.css">
</head>

<body>

<header class="main-header">
    <div class="header-content">
        <div class="header-text">
            <h1>
                <a href="Home.php" class="title-link">That Gaming Merch Store</a>
            </h1>
            <h2>Gear Up, Game on!</h2>
        </div>

            <div class="auth-links">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span> |
        <a href="cart.php" class="cart-link">
            🛒 Cart
            <?php
            // Optional: Show number of items in cart
            require 'auth/db.php';
            $stmt = $pdo->prepare("SELECT SUM(quantity) AS total_items FROM carts WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $cart_count = $stmt->fetch(PDO::FETCH_ASSOC)['total_items'];
            if ($cart_count > 0) {
                echo " ($cart_count)";
            }
            ?>
                </a> |
                <a href="auth/logout.php">Logout</a>
        <?php else: ?>
                  <a href="auth/login.php">Login</a> |
                  <a href="auth/register.php">Register</a>
                 <?php endif; ?>
            </div>
    </div>
</header>

<div class="game-list">

    <div class="game-card">
        <img src="images/games/cyberpunk.jpg" alt="Cyberpunk 2077">
        <div class="game-info">
            <h3>Cyberpunk 2077</h3>
            <p class="price">Rs 1,200</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME1">
                <input type="hidden" name="product_name" value="Cyberpunk 2077">
                <input type="hidden" name="price" value="1200">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/gowragnarok.jpg" alt="God of War Ragnarok">
        <div class="game-info">
            <h3>God Of War Ragnarok</h3>
            <p class="price">Rs 1,500</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME2">
                <input type="hidden" name="product_name" value="God of War Ragnarok">
                <input type="hidden" name="price" value="1500">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/gta5.jpg" alt="GTA 5">
        <div class="game-info">
            <h3>Grand Theft Auto 5</h3>
            <p class="price">Rs 1,150</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME3">
                <input type="hidden" name="product_name" value="GTA 5">
                <input type="hidden" name="price" value="1150">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/horrorpack.jpg" alt="Horror Pack">
        <div class="game-info">
            <h3>Game Pack: Horror</h3>
            <p class="price">Rs 9,500</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME4">
                <input type="hidden" name="product_name" value="HorrorPack">
                <input type="hidden" name="price" value="9500">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/ride.jpg" alt="Ride">
        <div class="game-info">
            <h3>Ride</h3>
            <p class="price">Rs 700</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME5">
                <input type="hidden" name="product_name" value="Ride">
                <input type="hidden" name="price" value="700">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/spiderman2.jpg" alt="Spider-Man 2">
        <div class="game-info">
            <h3>Spider-Man 2</h3>
            <p class="price">Rs 1,500</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME6">
                <input type="hidden" name="product_name" value="Spider-Man 2">
                <input type="hidden" name="price" value="1500">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <div class="game-card">
        <img src="images/games/streetfighter5.jpg" alt="Street Fighter 5">
        <div class="game-info">
            <h3>Street Fighter 5</h3>
            <p class="price">Rs 1,000</p>
            <button class="buy-btn">Buy Now</button>
            <form method="post" action="auth/add_to_cart.php">
                <input type="hidden" name="product_id" value="GAME7">
                <input type="hidden" name="product_name" value="Street Fighter 5">
                <input type="hidden" name="price" value="1000">
                <button type="submit" class="cart-btn">Add to Cart</button>
            </form>
        </div>
    </div>

</div>

<!-- Card Template CopyPaste 
<div class="game-card">
    <img src="images/games/.jpg" alt="Game X">
    <div class="game-info">
        <h3>Game Name</h3>
        <p class="price">Rs XXXX</p>
        <button class="buy-btn">Buy Now</button>
        <form method="post" action="add_to_cart.php">
                <input type="hidden" name="product_id" value="ID">
                <input type="hidden" name="product_name" value="Prod Name">
                <input type="hidden" name="price" value="Amount">
                <button type="submit" class="cart-btn">Add to Cart</button>
        </form>
    </div>
</div>
-->

</body>
</html>
